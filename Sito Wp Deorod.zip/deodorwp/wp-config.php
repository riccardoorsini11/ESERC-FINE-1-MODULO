<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordp' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'TfOICb^e|zGgGr5Z PwFkW$&2a#;a!zuWik5XFCg/Oq/n/-qfgeb%B3.D.<MnJGJ' );
define( 'SECURE_AUTH_KEY',  'i%fl`;p,4gTIVFv](iq]S[Q;.%-1!S5*/1W0EtH[%Z#Ut2*Q5$<_6pN;Qa5({35N' );
define( 'LOGGED_IN_KEY',    'T!DuC1r=KH0YFv0bNGVoxQx1jgnHw88PJ!Jz728Vc+%ydH&20lLS 5SnzG)T%5F.' );
define( 'NONCE_KEY',        '<f1DW<{c>qRR:{^CBF2}oriJ?+_6_r5kash;3xm7N6TcagD`XcG=rTjIuj8C=`eD' );
define( 'AUTH_SALT',        'J%/M!$KuNS$PeiP+r]17%}+x$90As[/y~3%g9`_mKPk]Z$ u{F_!lR4>?x$||7VR' );
define( 'SECURE_AUTH_SALT', '|jj.7uFDhunkFo/4Pj!}^q9m@zg!/wU{rd78<P}hh320-I@UM^=|+HpA4>%I$h7x' );
define( 'LOGGED_IN_SALT',   '.X}0%+?q(>DCO{cu;,$K^[x%Q-Zy8:;q;6Aiz2i]]<Jd}!N3nR70=6>c=FTAG6jW' );
define( 'NONCE_SALT',       '@L3xuU}+f{#{T0y-f,Fax;D44>Ixm$4K_!(W2.T|Hr_2#zzV{w&ae#sv+jg#uc%$' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
